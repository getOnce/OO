define([], function() {
    "use strict";
    return {
        init: function(bnObj, prefix) {
            var _this = this;
            prefix = prefix || '';
            $.each(bnObj, function(k, v) {
                if($.isFunction(v.func)) {
                    $(document.body).on(v.eventType || qyerUtil.EVENT.CLICK, k, function(evt) {
                        var $node = $(evt.currentTarget);
                        var ipg = prefix + v.func($node.index(), evt);
                        _this.doTrackCode(ipg, $node);
                    });
                } else {
                    $(k).attr('data-bn-ipg', $.isFunction(v) ? function() {
                        return prefix + v.apply(this, arguments);
                    } : prefix + v);
                }
            });
        },
        doTrackCode: function (ipg, $node) {
            var href = $node && $node.attr('href');
            if(href && /^(?!javascript:)/gi.test(href)) {
                var id = '__dotarckcodea__';
                var $a = $('#' + id);
                if($a.length == 0) {
                    $a = $('<a id="'+id+'" style="display:none;">dotarckcodea</a>').on('click', function(e) {
                        e.preventDefault();
                    }).appendTo(document.body);
                }
                $a.attr({
                    target: '_blank',
                    "data-bn-ipg": ipg,
                    href: href
                }).trigger('click');
            } else {
                qyerUtil.doTrackCode(ipg);
            }
        }
    }
});