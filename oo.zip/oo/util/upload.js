/**
 * @fileOverview 文件上传
 * @author pk
 * @revision 1.0
 */
define(['common/ui/upload/upload'], function(Upload) {
	"use strict";
    /**
     * 对plupload.Uploader进行扩展
     * 上传文件,主要用于失败重试
     * @method qUploadFile
     * @for plupload.Uploader
     * @param {File} file 需要上传的文件
    */
    plupload.Uploader.prototype.qUploadFile = function(file) {
        if (this.trigger("BeforeUpload", file)) {
            this.state = plupload.STARTED;
            file.status = plupload.UPLOADING;
            this.trigger("UploadFile", file);
        }
    };

    return Upload;
});