define(function(){
	function AutoHeight(opt){
        $.extend(this,opt||{});
        this.commonProperty = {
            placeholder:"data-placeholder",
            status:"data-change",
            statusValues:["change","empty"]
        }
        this.init();
    }
    AutoHeight.prototype = {
        exClass:"",
        emptyClass:"poi-colorOn",
        changeClass:"",
        setText:function(text){
            this.$el.setText(text);
        },
        addClass:function(classname){
            this.$el.addClass(classname);
            return this;
        },
        removeClass:function(classname){
            this.$el.removeClass(classname);
            return this;
        },
        checkText:function(){
            var text = $.trim(this.$el.text());
            if(text==""){
                return 1;
            }
            else if(text==this.$el.attr(this.commonProperty.placeholder)){
                return 2
            }else{
                return 3
            }
        },
        toggleStatus:function(arg){
            var status = this.$el.attr(this.commonProperty.status);
            this.$el.attr(this.commonProperty.status,this.commonProperty["statusValues"][arg?0:1]);
            return this;
        },
        handler:function(i){

            switch(i||this.checkText()){
                case 1:
                case 2:
                this
                .toggleStatus()
                .removeClass(this.changeClass)
                .addClass(this.emptyClass)
                .$el.text(this.$el.attr(this.commonProperty.placeholder));
                break;
                case 3:
                default:
                this
                .toggleStatus(true)
                .removeClass(this.emptyClass)
                .addClass(this.changeClass);
                break
            }
        },
        bindEvent:function(){
            var me = this,timer = null;;
            me.$el.on("blur",function(){
                me.handler.call(me);
            })
            .on("focus",function(){
                if(me.checkText()!=3){
                    me
                    .removeClass(me.emptyClass)
                    .addClass(me.changeClass)
                    .$el
                    .text("");
                }
                if(timer)clearTimeout(timer);
                timer = setTimeout(function(){
                    if(!document.createRange)return;
                    var sel = null,range = null;
                    range = document.createRange();
				    range.selectNodeContents(me.$el.get(0));
				    range.collapse(true);
				    range.setEnd(me.$el.get(0), me.$el.get(0).childNodes.length);
				    range.setStart(me.$el.get(0), me.$el.get(0).childNodes.length);
				    sel = window.getSelection();
				    sel.removeAllRanges();
				    sel.addRange(range);
                },10)
            });
            return this;
        },
        init:function(){
            var me = this;
            me.bindEvent().handler();
            if(me.exClass){
            	me.addClass(me.exClass);
            }
        }
    }
    return AutoHeight;
})