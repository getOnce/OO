define(function(){
	function isFromApp(){
		var search = window.location.search,
		 value = search.indexOf('from_device=app');
		 return value==-1?false:true;
	}
	return isFromApp();
});