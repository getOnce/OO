define(['common/util/geolocation'],function (position) {
    if(!window.isGetPosition){
        window.isGetPosition = {};
    }
    position.getCurrentPosition(function(position) {
        document.cookie = "place_mobile_user_lat="+position.coords.latitude+";path=/;domain=m.qyer.com";
        document.cookie = "place_mobile_user_lng="+position.coords.longitude+";path=/;domain=m.qyer.com";
        window.isGetPosition = {
            get:true,
            place_mobile_user_lat:position.coords.latitude,
            place_mobile_user_lng:position.coords.longitude
        }
    },function(){
        window.isGetPosition = {get:false};
    });
})

















