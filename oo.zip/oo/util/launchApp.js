define(['common/util/checkUserAgent'],function(ck){

	function LaunchApp(){
		this.agent = ck();
	}
	LaunchApp.prototype = {
		createIframe:function(){
			var iframe = document.createElement("iframe");
	        
	        iframe.style.display = "none";
	        document.body.appendChild(iframe);

		},
		mainFunction:function(){
			var start = new Date().getTime(),me = this;;
			//this.createIframe();
		//window.location.href = this.url;
			// var end = new Date().getTime(),
	  		// elapsed = (end - start);
	        
	  		// start = end = elapsed = null;
	        // setTimeout(function(){
	        // 	window.location.href = 'http://www.qyer.com';
	        // },1000);
			switch(me.agent){
				case 'android':
				if(typeof me.androidUrl =='undefined'){
					return;
				}
				var $la = $("#js-launchApp_1");
				if(!$la.length){
					$la = $('<a id="js-launchApp_1" href="'+me.androidUrl+'"></a>').appendTo("body");
				}
				$la.trigger("click");

          		setTimeout(function() { window.location = (me.url||me.androidDownUrl); }, 25);
				;break;
				case 'iphone':
				var $la = $("#js-launchApp_1");
				if(!$la.length){
					$la = $('<a id="js-launchApp_1" href="'+me.iphoneUrl+'"></a>').appendTo("body");
				}
				$la.trigger("click");
          		setTimeout(function() { window.location = (me.url||me.iphoneDownUrl); }, 25);
          		$(me).trigger("eventClick");
				break;

			}

	        
		},
		/**
		*启动app
		*@param opt {object}参数
		*@oaram opt.url 启动app的url
		*/
		init:function(opt){
			$.extend(this,opt||{});
			this.mainFunction();
		}
	}
	
	var goToApp = new LaunchApp();
	return goToApp;
	    
	    
})






























