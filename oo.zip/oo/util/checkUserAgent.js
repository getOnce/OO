define(function(){
	function CheckUserAgent(){
		var UA = navigator.userAgent;
		if (UA.indexOf('Android') > -1 || UA.indexOf('Linux') > -1) {//安卓手机
			return 'android'
		} else if (UA.indexOf('iPhone') > -1) {//苹果手机
			return 'iphone'
		} else if (UA.indexOf('Windows Phone') > -1) {//winphone手机
			return 'windows'
		}else{
			return 'android'
		}
	}
	return CheckUserAgent;
})