"use strict";
define(function() {
	return {
        getCurrentPosition: function(success, error) {
            if(navigator.geolocation) {
                /*success({
                    coords: {
                        latitude: 12949638.56,
                        longitude: 4790051.47
                    }
                });*/
                navigator.geolocation.getCurrentPosition(success, error);
            } else {
                error({
                    NOT_SUPPORTED: 0,
                    code: 0
                });
            }
        }
    };
});