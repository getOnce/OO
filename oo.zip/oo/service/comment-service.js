"use strict";
define(['./service', './urls', '../util/template'], function(service, urls, template) {
	return {
        //添加评论
        addComment: function(data, success, error) {
            /*setTimeout(function(){
                success({
                    "error_code": 0,
                    "result": "ok",
                    "data": {
                        "msg": "点评成功",
                        "ranking": 0,
                        "signrank": 0,
                        "commentcount": 1,
                        "differcount": 1,
                        "html": "<p class=\"icons\"><img src=\"http://static.qyer.com/images/place/pup/promote_a1.png\" width=\"74\" height=\"74\" alt=\"\" /></p>\n        <div class=\"infos\">\n            <p class=\"tit fontYaHei\">你是点评的</p>\n            <p class=\"sum fontYaHei\"><img src=\"http://static.qyer.com/images/place/pup/icon_star2.png\" alt=\"\" /><span>第 <em>1</em> 人</span><img src=\"http://static.qyer.com/images/place/pup/icon_star2.png\" alt=\"\" /></p>\n            <p class=\"txt\">缘分啊！</p>\n        </div>",
                        "commentid": 26456,
                        "imagecount": "2",
                        "images": {
                            "0": {
                                "id": "7499270",
                                "like_count": "0",
                                "album_id": "266582",
                                "description": null,
                                "photo_time": "0",
                                "country_id": "11",
                                "city_id": "50"
                            },
                            "1": {
                                "id": "7499269",
                                "like_count": "0",
                                "album_id": "266582",
                                "description": null,
                                "photo_time": "0",
                                "country_id": "11",
                                "city_id": "50"
                            },
                            "count": "2"
                        },
                        "money": {
                            "credit_jy": 10,
                            "credit_qb": 10,
                            "credits2": 10,
                            "credits3": 10
                        },
                        "edit": false
                    }
                });
            }, 1000);
            return;*/
            
            data.source_type = 52;
			return service.post(urls.addComment, data, success, error);
        },
        getCommentList: function(page, success, error) {
            return service.get(template.render(urls.getCommentList, {page: page}), {star:$("#tabs").find("li[data=filter]").attr("data-data"),order:$("#tabs").find("li[data=sort]").attr("data-data")}, success, error);
        },
        //点赞
        impress: function(pid, success, error) {
            //success({error_code: 0, result: "ok", data: {msg: "操作成功", id: 0, msg_impel: "英雄所见略同，期待你发现更多的有用！经验+1"}});
            //success({error_code: 4, result: "error", data: {msg: "您已经点击过有用了。"}});
            //return;

            var data = {
                pid: pid,//评论id
                num: 1,
                type: 2
            };
            return service.post(urls.impress, data, success, error);
        }
    };
});