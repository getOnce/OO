"use strict";
define(['./service', './urls'], function(service, urls){
	return {
		getPreviosMenu: function(success, error){
			return service.get(urls.getPreviosMenu, {}, success, error);
		}
	}
})