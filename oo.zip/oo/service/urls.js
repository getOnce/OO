"use strict";
define(function() {
    return {
        //根据经纬度获取城市信息
        //{"error_code":0,"result":"ok","data":{"name":"\u585e\u7ef4\u5229\u4e9a","url":"http:\/\/m.qyer.com\/place\/seville\/"}}
        getCityByLatlng: '/place/city.php?action=ajaxGetNowCity',//&lat=XX&lng=XX

        //获取国家线路列表
        //{"error_code":0,"result":"ok","data":[{"url":"http:\/\/plan.qyer.com\/trip\/V2AJY1FuBzRTYFI3\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/18d\/66\/1848223\/index\/500","title":"keyjie\u7684\u884c\u7a0b","city":["\u5e7f\u4e1c\u7701","\u9999\u6e2f","\u6fb3\u95e8"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2cJYFFgBz9TYVI9\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/212\/16\/Q0hXQxwGaA\/index\/500","title":"\u53f0\u6e7e","city":["\u4e0a\u6d77","\u53f0\u5317","\u9ad8\u96c4\u5e02","\u57a6\u4e01"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2cJa1FlBzFTZ1I7\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/182\/fc\/2005594\/index\/500","title":"\u53f0\u5317\u4e03\u65e5\u81ea\u7531\u884c","city":["\u4e0a\u6d77","\u53f0\u5317","\u9ad8\u96c4\u5e02","\u57a6\u4e01"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2AJZVFvBzVTZFI5\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/213\/12\/Q0hWQxgBZw\/index\/500","title":"hahaha","city":["\u4e0a\u6d77","\u53f0\u5317","\u9ad8\u96c4\u5e02","\u57a6\u4e01"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2AJY1FnBzRTY1I-\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/326\/80\/QktTShoFZQ\/index\/500","title":"yangyousong\u7684\u884c\u7a0b","city":["\u53f0\u5317","\u5929\u6d25","\u65b0\u5317\u5e02","\u6de1\u6c34","\u65b0\u7af9","\u53f0\u4e2d\u5e02","\u5357\u6295\u53bf","\u5609\u4e49","\u963f\u91cc\u5c71","\u9ad8\u96c4\u5e02","\u57a6\u4e01","\u53f0\u4e1c\u53bf","\u82b1\u83b2\u53bf","\u82b1\u83b2\u592a\u9c81\u9601\uff0c\u7901\u6eaa","\u7901\u6eaa","\u57fa\u9686","\u6843\u56ed\u53bf"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2AJZVFuBz5TYVI4\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/454\/67\/RUxRRB0PYA\/index\/500","title":"BC","city":["\u53f0\u5317","\u6de1\u6c34","\u65b0\u5317\u5e02","\u5e73\u6eaa","\u4e5d\u4efd"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2YJYlFgBz9TZlI8\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/454\/67\/RUxRRB0PYA\/index\/500","title":"\u3010\u95fa\u871c\u6e38\u3011\u53f0\u5317\u6df1\u5ea66\u59295\u591c\u4e4b\u65c5","city":["\u53f0\u5317","\u6de1\u6c34","\u65b0\u5317\u5e02","\u5e73\u6eaa","\u4e5d\u4efd"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2AJZVFuBz5TYVI7\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/1f4\/10\/1985265\/index\/500","title":"BC","city":["\u53f0\u5317","\u6de1\u6c34","\u65b0\u5317\u5e02","\u5e73\u6eaa","\u4e5d\u4efd"]},{"url":"http:\/\/plan.qyer.com\/trip\/V2AJZVFuBz5TYVI6\/map","img":"http:\/\/test1362383214.qiniudn.com\/album\/user\/454\/67\/RUxRRB0PYA\/index\/500","title":"BC","city":["\u53f0\u5317","\u6de1\u6c34","\u65b0\u5317\u5e02","\u5e73\u6eaa","\u4e5d\u4efd"]}]};
		getCountryRouteList: location.href.split('?')[0] + '?ajax=country_1&page=<%:=page%>',//'/place/<%:=country%>/plan/?ajax=country_1&page=<%:=page%>',
		
        //获取国家折扣列表
        //{"error_code":0,"result":"ok","data":[{"title":"\u79df\u8f669","pic":"","url":"http:\/\/z.qyer.com\/deal\/41108\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6618","pic":"","url":"http:\/\/z.qyer.com\/deal\/41117\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6617","pic":"","url":"http:\/\/z.qyer.com\/deal\/41116\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6616","pic":"","url":"http:\/\/z.qyer.com\/deal\/41115\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6615","pic":"","url":"http:\/\/z.qyer.com\/deal\/41114\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6614","pic":"","url":"http:\/\/z.qyer.com\/deal\/41113\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6613","pic":"","url":"http:\/\/z.qyer.com\/deal\/41112\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6612","pic":"","url":"http:\/\/z.qyer.com\/deal\/41111\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6611","pic":"","url":"http:\/\/z.qyer.com\/deal\/41110\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6610","pic":"","url":"http:\/\/z.qyer.com\/deal\/41109\/","buy_price":"5","sale_count":0,"liang_dian":[]}]};
		getCountryDiscountList: location.href.split('?')[0] + '?ajax=country_2&page=<%:=page%>',//'/place/<%:=country%>/plan/selection/?ajax=country_2&page=<%:=page%>'
    	
    	//获取城市折扣列表
		//{"error_code":0,"result":"ok","data":[{"title":"\u79df\u8f669","pic":"","url":"http:\/\/z.qyer.com\/deal\/41108\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6618","pic":"","url":"http:\/\/z.qyer.com\/deal\/41117\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6617","pic":"","url":"http:\/\/z.qyer.com\/deal\/41116\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6616","pic":"","url":"http:\/\/z.qyer.com\/deal\/41115\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6615","pic":"","url":"http:\/\/z.qyer.com\/deal\/41114\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6614","pic":"","url":"http:\/\/z.qyer.com\/deal\/41113\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6613","pic":"","url":"http:\/\/z.qyer.com\/deal\/41112\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6612","pic":"","url":"http:\/\/z.qyer.com\/deal\/41111\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6611","pic":"","url":"http:\/\/z.qyer.com\/deal\/41110\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6610","pic":"","url":"http:\/\/z.qyer.com\/deal\/41109\/","buy_price":"5","sale_count":0,"liang_dian":[]}]};
		getCityDiscountList: location.href.split('?')[0] + '?ajax=city_1&page=<%:=page%>',//'/place/<%:=country%>/plan/selection?ajax=country_2&page=<%:=page%>'

        //获取折扣列表 http://m.qyer.com/place/paris/z?cate=cityfun/wifi&ajax=1&page=
        getDiscountList: window.discount_list_ajax_url + '<%:=page%>',

        getEventPoiList: ((typeof(_getEventPoiUrl)=='undefined'?location.href.split('?')[0]:_getEventPoiUrl) + '?ajax=1&page=<%:=page%>'),

        //poi收藏页获取二级类别
        //http://m.qyer.com/place/favorite.php?action=getTagByCategory&category_id=78&city_id=50
        getTagByCategory: '/place/favorite.php?action=getTagByCategory',
        //poi收藏页loadmore
        getFavoritePoiList: location.pathname + '?ajax=1&page=<%:=page%>',
        //poi收藏页url
        poiFavorite: '/place/<%:=city%>/favorite/<%:=countryId%>_<%:=categoryId%>_<%:=tagId%>_<%:=sortId%>?back_id=<%:=backId%>',
        /**
         *  评论
         *  post data
         *  {
         *      poiid: 33741,//poiid
         *      starlevel: 4,//星级评分
         *      comment: '',//评论内容
         *      imgs: '7499270,7499269',//图片keys
         *      source_type: 52//固定值
         *  }
         */
        addComment: '/place/comment.php/?action=savePoiComment',
        //评论列表页loadmore
        getCommentList: location.pathname + (location.search?'&':'?') + 'ajax=1&page=<%:=page%>',
        /**
         *  评论点赞
         *  post data
         *  {
         *      pid: pid,//评论id
         *      num: 1,//固定值
         *      type: 2//固定值
         *  }
         */
        impress: '/place/impress.php/?action=useful',
        //获取图片列表
        getImageList: location.pathname + (location.search?'&':'?') + 'ajax=1&page=<%:=page%>',
        getImageListById: '/place/album.php?action=get_photos_by_place&id=<%:=id%>&place_id=<%:=place_id%>&type=<%:=type%>&operate=<%:=operate%>',
        //取得先前的订单<酒店、周边门票等>
        getPreviosMenu: '/place/trip/history',
    };
});






