"use strict";
define(['./service', './urls', '../util/template'], function(service, urls, template) {
	return {
        //获取poi
        getImageList: function(page, success, error) {
			/*var r = {
				"error_code": 0,
				"result": "ok",
				"data": {
					"list": [
						{
							"src": "images/e1.jpg",
							"thumb": "images/e1.jpg"
						},
						{
							"src": "images/e2.jpg",
							"thumb": "images/e2.jpg"
						},
						{
							"src": "images/e3.jpg",
							"thumb": "images/e3.jpg"
						},
						{
							"src": "images/e4.jpg",
							"thumb": "images/e4.jpg"
						},
						{
							"src": "images/e7.jpg",
							"thumb": "images/e7.jpg"
						}
					]
				}
			};
			return setTimeout($.proxy(success, null, r), 1000);*/
			
            return service.get(template.render(urls.getImageList, {page: page}), {}, success, error);
        },
        /**
	    *@param id {number} 图片id
	    *@param place_id {number} 目的地id[国家id、区域id、城市id、poiid]
	    *@param type {string} [country、city、poi、area]
	    *@param operate {number} 取图片[前|后]边的数据[1==prev、2==next]
	    */
	    getImageListById: function(id, place_id, type, operate, success, error){
	    	/*var r = {
					"error_code": 0,
					"result": "ok",
					"data": {
						"list": [
							{"id":"7496245","url":"http:\/\/test1362383214.qiniudn.com\/album\/user\/749\/62\/Rk1cRBgDZQ\/index"},
							{"id":"7496244","url":"http:\/\/test1362383214.qiniudn.com\/album\/user\/749\/62\/Rk1cRBgDZA\/index"},
							{"id":"7496236","url":"http:\/\/test1362383214.qiniudn.com\/album\/user\/749\/62\/Rk1cRBgEZg\/index"}
						]
					}
				};*/
	    	return service.get(template.render(urls.getImageListById, {id: id, place_id: place_id, type: type, operate: operate}), {}, success, error);
	    }
    }
    
});












