"use strict";
define(['./service', './urls'], function(service, urls) {
	return {
        getCityByLatlng: function(lat, lng, success, error) {
            return service.get(urls.getCityByLatlng, {lat: lat, lng: lng}, success, error);
        }
    };
});