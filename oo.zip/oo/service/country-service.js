"use strict";
define(['./service', './urls', '../util/template'], function(service, urls, template) {
	return {
		//获取国家景点路线
        getCountryRouteList: function(page, success, error) {
            return service.get(template.render(urls.getCountryRouteList, {page: page}), {}, success, error);
        },
        //获取国家折扣
        getCountryDiscountList: function(page, success, error) {
			//var r = {"error_code":0,"result":"ok","data":[{"title":"\u79df\u8f669","pic":"","url":"http:\/\/z.qyer.com\/deal\/41108\/","buy_price":"5","sale_count":0,"liang_dian":["aaa", "\u79df\u8f6618", '阿卡']},{"title":"\u79df\u8f6618","pic":"","url":"http:\/\/z.qyer.com\/deal\/41117\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6617","pic":"","url":"http:\/\/z.qyer.com\/deal\/41116\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6616","pic":"","url":"http:\/\/z.qyer.com\/deal\/41115\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6615","pic":"","url":"http:\/\/z.qyer.com\/deal\/41114\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6614","pic":"","url":"http:\/\/z.qyer.com\/deal\/41113\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6613","pic":"","url":"http:\/\/z.qyer.com\/deal\/41112\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6612","pic":"","url":"http:\/\/z.qyer.com\/deal\/41111\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6611","pic":"","url":"http:\/\/z.qyer.com\/deal\/41110\/","buy_price":"5","sale_count":0,"liang_dian":[]},{"title":"\u79df\u8f6610","pic":"","url":"http:\/\/z.qyer.com\/deal\/41109\/","buy_price":"5","sale_count":0,"liang_dian":["abc"]}]};
			//return setTimeout($.proxy(success, null, r), 100);
			
            return service.get(template.render(urls.getCountryDiscountList, {page: page}), {}, success, error);
        }
    };
});