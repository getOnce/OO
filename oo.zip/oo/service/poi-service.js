"use strict";
define(['./service', './urls', '../util/template'], function(service, urls, template) {
	return {
        //poi收藏页面获取tag
        getTagByCategory: function(category_id, city_id, success, error) {
			return service.get(urls.getTagByCategory, {
				category_id: category_id,
				city_id: city_id
			}, success, error);
        },
        //poi收藏页面poi loadmore
        getFavoritePoiList: function(page, success, error) {
        	/*setTimeout(function(){
        		success({
        			data: poiList
        		});
        	}, 1000);
        	return;*/
        	
            return service.get(template.render(urls.getFavoritePoiList, {page: page}), {}, success, error);
        }
    };
});