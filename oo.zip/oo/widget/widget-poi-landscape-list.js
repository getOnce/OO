define(["./widget-landscape-list"], function(LandscapeList) {
    "use strict";
    return LandscapeList.createClass({
        init: function() {
            this.callSuper.apply(this, arguments);
            this.resetWidth().resetHeight();
        },
        resetHeight: function() {
            var $imgBox = $('>li .poi-img', this.getThumbNode());
            $imgBox.height($imgBox.width());
            return this.callSuper.apply(this, arguments);
        }
    });
});