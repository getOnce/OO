"use strict";
define(["./widget-popup", 'common/util/template', 'common/widget/widget-img-swipe'], function(Widget, template, ImgSwipe) {
	return Widget.createClass({
        events: [
            [qyerUtil.EVENT.CLICK, 'hide', '.qui-header .icon-place-header-back']
        ],
        init: function(params) {
            this.callSuper.apply(this, arguments);
            this.imgSwipe = new ImgSwipe().on(ImgSwipe.EVENTS.CHANGE, $.proxy(function() {
                this.update();
            }, this));
        },
        html: function(data) {
            var tpl = this.template();
            var html = template.render(tpl, data);
            return html;
        },
        template: function() {
            return [
                '<section class="img-swipe-popup">',
                '    <header class="qui-header">',
                '        <div class="qui-header-left"><a class="icon-place icon-place-header-back"></a></div>',
                '        <a class="qui-header-title"></a>',
                '    </header>',
                '</section>'].join('');
        },
        show: function(pos, items) {
            this.callSuper(this.html(), $.proxy(function() {
                this.imgSwipe.$().appendTo(this.$('.img-swipe-popup'));
                this.imgSwipe.show(pos, items);
            }, this));
        },
        update: function() {
            this.$('.qui-header .qui-header-title').html(this.getPos() + ' / ' + this.getCount());
        },
        getPos: function() {
            return this.imgSwipe.getPos() + 1;
        },
        getCount: function() {
            return this.imgSwipe.size();
        }
    });
});