define(["./widget-landscape-scrollbox"], function(LandscapeScrollbox) {
    "use strict";
    return LandscapeScrollbox.createClass({
        resetWidth: function() {
            var $listview = this.getThumbNode();
            var $li = $('>li', $listview);
            var w = $li.width();

            $listview.width($li.length * w + 12).addClass('ready');
            $li.width(w);

            return this;
        }
    });
});