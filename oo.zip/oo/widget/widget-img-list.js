"use strict";
define(["./widget"], function(Widget) {
    return Widget.createClass({
        //宽高比
        aspectRatio: 2/1,
        init: function(args) {
            this.callSuper.apply(this, arguments);
            this.aspectRatio = args.aspectRatio || this.aspectRatio;
            this.setHeight();
        },
        setHeight: function() {
            var items = this.$('>a>p');
            var height = this._height = items.width() / this.aspectRatio;
            items.height(height);
        },
        getHeight: function() {
            return this._height;
        }
    });
});