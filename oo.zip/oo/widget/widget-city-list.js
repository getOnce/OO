"use strict";
define(["./widget"], function(Widget) {
    var CityList = Widget.createClass({
        events: [
            ['scroll', 'checkLetterPosition']
        ],
        init: function() {
            this.callSuper.apply(this, arguments);
            
            /* 生成测试数据 开发完成需要删除 */
            /*var $cityList = this.$('.city-list li');
            for(var i = 65; i <= 90; i++) {
                var $cityListClone = $cityList.clone();
                $cityListClone.first().html('');
                $cityListClone.html(function(index, html){return String.fromCharCode(i) + html;});
                this.$('.city-list').append($cityListClone);
            }
            $cityList.remove();*/
            /* 生成测试数据 开发完成需要删除 end */


            var $letterList = this.$('.city-list li.letter');
            var letters = [];
            /*for(var i = 65; i <= 90; i++) {
                arr.push('<li>' + String.fromCharCode(i) + '</li>');
            }*/
            $letterList.each(function() {
                letters.push($(this).text());
            });


            new LetterList({
                $el: this.$('.letter-list'),
                letters: letters
            }).on(LetterList.EVENTS.CHANGE, $.proxy(function(evt, letter) {
                this.showLetter(letter);
            }, this));

        },
        checkLetterPosition: function(evt) {
            var css = {
                top: null,
                position: null
            };
            var top = this.$el.offset().top + (this.$el.height() - $('.letter-list').height())/2;
            if(this.$('.all-city').offset().top < top) {
                css = {
                    top: top,
                    position: "fixed"
                };
                $('.letter-list').appendTo(document.body);
            } else {
                $('.letter-list').appendTo(this.$('.all-city'));
            }
            $('.letter-list').css(css);
        },
        showLetter: function(letter) {
            var $node = this.$('.city-list li').filter(function(){return $(this).text() === letter;});
            this.scrollIntoView($node);
        },
        scrollIntoView: function($node, offset) {
            if($node && $node.length) {
                var scrollTop = $node.offset().top + this.$el.scrollTop() - this.$el.offset().top + (offset || 0);
                this.$el.scrollTop(scrollTop);
            }
        }
    });

    var LetterList = Widget.createClass({
        events: [
            [qyerUtil.EVENT.CLICK, '_selectByEvent', 'li'],
            ['touchstart', 'touchstart'],
            ['touchmove', 'touchmove'],
            ['touchend', 'touchend']
        ],
        _touchstart_touch: null,
        _classname_highlight: 'highlight',
        init: function(params) {
            this.callSuper.apply(this, arguments);
            var arr = [];
            $.each(params.letters || this.letters || [], function(i, letter) {
                arr.push('<li>' + letter + '</li>');
            });
            this.$().html(arr.join(''));
        },
        touchstart: function(evt) {
            this._touchstart_touch = evt.changedTouches[0];
        },
        touchmove: function(evt) {
            evt.preventDefault();

            var node = this.getElementByPoint({
                x: this._touchstart_touch.clientX,
                y: evt.changedTouches[0].clientY
            });
            var $children = $(evt.currentTarget).children();
            if($children.indexOf(node) >= 0) {
                $children.removeClass(this._classname_highlight);
                var $node = $(node).addClass(this._classname_highlight);
                this._selectByNode($node);
            }
        },
        touchend: function(evt) {
            this._touchstart_touch = null;
            $(evt.currentTarget).children().removeClass(this._classname_highlight);
        },
        select: function(letter, evt) {
            this.trigger(this.getStatic().EVENTS.CHANGE, letter, evt);
        },
        _selectByEvent: function(evt) {
            this.select(evt.currentTarget.innerHTML, evt);
        },
        _selectByNode: function($node, evt) {
            this.select($node.html(), evt);
        },
        getElementByPoint: function(point) {
            return document.elementFromPoint(point.x, point.y);
        }
    }, {
        EVENTS: {
            CHANGE: 'change'
        }
    });

    return CityList;
});