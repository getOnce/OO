define(['common/widget/widget-img-list', 'common/util/template', 'common/util/upload', 'common/util/util-file'], function(Widget, template, Upload, fileUtil) {
    "use strict";
    var util = {
        toArray:function (a) {
            if(!a.length){
                return [];
            }
            return Array.prototype.slice.call(a)
        },
        toObject:function(a){
            if(!a.length){
                return {}
            }
            var maxLength = 0;
            var curLength = maxLength = a.length,arr = [];
            while(curLength--){
                arr.push({
                    key:a[maxLength-curLength-1]
                })
            }
            return arr;
        }
    }
    return Widget.createClass({
        aspectRatio: 1,
        events: [
            [qyerUtil.EVENT.CLICK, '_evt_remove', 'a > div.remove'],
        ],
        tpl: [
            '<%for(var i = 0, $item; $item = data[i]; i++) {%>',
            '<a id="file_<%=$item.id%>" data-file-id="<%=$item.id%>"><p style="height:<%=height%>px;"><img style="background-image:url(<%=$item.src%>)" src="http://static.qyer.com/images/m/space.png"></p><div class="process"><span></span></div><div class="remove icon-place icon-place-close"></div></a>',
            '<%}%>'].join(''),
        init: function(arg0, arg1) {
            this.callSuper.apply(this, arguments);
            this.tpl = arg0.tpl || this.tpl;
            this._initUpload(arg1);
        },
        _initUpload: function(conf) {
            var _this = this,_key = null;
            this.upload = new Upload($.extend(true, {
                runtimes: 'html5,html4',
                qyer_token_url: "/place/qcross/www/api.php?action=getAlbumToken",
                //qyer_token_url: 'qyer_token.js',
                max_file_size: '5mb',
                browse_button: this.$('.file-add').get(0),
                container: this.$('.file-add-box').get(0),
                auto_start: false,
                filters: {
                    mime_types:[
                        {
                            title: "Image files",
                            extensions: "jpg,gif,png,jpeg"
                        }
                    ]
                },
                init: {
                    FilesAdded: function(up, files) {
                        //console.log('FilesAdded', up, files);
                        $.each(files, function(i, file) {
                            fileUtil.getSrcByFile(file.getNative(), function(src) {
                                file.src = src;
                                _this.renderData({height: _this.getHeight(), data: [file]});
                            });
                        });
                        
                        up.start();
                    },
                    BeforeUpload: function(up, file) {
                        //console.log('BeforeUpload', window.file=file);
                        
                    },
                    UploadProgress: function(up, file) {
                        //console.log('UploadProgress', up, file);
                        _this.showProgressByFile(file);
                    },
                    UploadComplete: function() {
                        //console.log('UploadComplete', arguments)
                    },
                    FileUploaded: function(up, file, info) {
                        _this
                        .$("a[data-file-id="+file.id+"]")
                        .attr("data-key",JSON.parse(info).key);
                        
                    },
                    Error: function(up, err, errTip) {
                        //console.log('Error', up, err, errTip);
                        _this.showErrorByFile(err.file, function() {
                            up.qUploadFile(err.file);
                        });
                    },
                    'Key':function(up,file){
                        var key = new Date().getTime();
                        key += parseInt(Math.random()*1000);
                        key += window.QYER?(""+window.QYER.uid):"";
                        //上传多张图片时，第一个张图片先走key，然后多张图片一起走filesAdded方法，那么后边的几张图片就没有可以，无法显示。
                        //fixed：做个判断，如果无法从图片列表中获取图片，则表明是第一张图片，否则不是第一张图片，那么将从图片列表中，获取图片并添加可以，以便提交保存图片时使用。
                        
                        return key;
                    }
                }
            }, conf));
            this.on(this.getStatic('EVENTS').REMOVE, function(evt, fileID) {
                var uploader = this.upload.uploader;
                uploader.getFile(fileID) && uploader.removeFile(fileID);
            });
        },
        html: function(data) {
            var tpl = this.template();
            var html = template.render(tpl, data);
            //console.log(tpl);
            //console.log(html);
            return html;
        },
        template: function() {
            return this.tpl;
        },
        renderData: function(data) {
            this.$().prepend(this.html(data));
        },

        _evt_remove: function(evt) {
            this.remove($(evt.currentTarget).parent().data('file-id'));
        },
        remove: function(fileID) {
            var $node = this.getFileNode(fileID);
            $node && $node.remove();

            this.trigger(this.getStatic('EVENTS').REMOVE, fileID);
        },
        getFileNode: function(fileID) {
            return this.$('#file_' + fileID);
        },
        getFileNodeByFile: function(file) {
            return this.getFileNode(file.id);
        },
        showProgress: function(fileID, percent) {
            this.hideError(fileID);
            var $node = this.getFileNode(fileID);
            $('.process', $node).height((1-percent/100) * $node.height());
        },
        showProgressByFile: function(file) {
            this.showProgress(file.id, file.percent);
        },
        showError: function(fileID, cb) {
            var $node = this.getFileNode(fileID);
            var $msg = $('.msg', $node);
            if(!$msg.length) {
                $msg = $('<div class="msg error"><p><span>上传失败<b>重新上传</b></span></p></div>').appendTo($node);
            }
            var eventName = qyerUtil.EVENT.CLICK + '.error';
            $msg.off(eventName).on(eventName, cb);
        },
        hideError: function(fileID) {
            var $node = this.getFileNode(fileID);
            var $msg = $('.msg', $node);
            $msg.remove();
        },
        showErrorByFile: function(file, cb) {
            this.showError(file.id, cb);
        },
        //执行保存照片，取得id
        savePhoto:function(){
            var _this = this,
            ids = util.toArray(_this.$("a[data-key]").map(function(a,b){return $(b).attr("data-key")}));
            if(!ids.length){
                //没有图片的情况
                _this.trigger(_this.getStatic('EVENTS').eventSavePhoto,false);
                return ;
            }
            ids = util.toObject(ids);
            qyerUtil.doAjax({
                onSuccess:function(data){
                    _this.trigger(_this.getStatic('EVENTS').eventSavePhoto,data);
                },
                onError:function(data){
                    _this.trigger(_this.getStatic('EVENTS').eventSavePhotoError,data);
                },
                url:"/api.php?action=saveUploadAlbumPhoto",
                data:{photo:ids}
            });
        }
    }, {
        EVENTS: {
            REMOVE: 'remove',
            //保存照片
            eventSavePhoto:"eventSavePhoto",
            //保存照片错误
            eventSavePhotoError:"eventSavePhotoError"
        }
    });
});








