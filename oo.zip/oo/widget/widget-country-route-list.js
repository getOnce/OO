define(['common/widget/widget', 'common/util/template', 'common/service/country-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
        pageNum: 10,
        service: null,
        init: function(arg0) {
            this.callSuper.apply(this, arguments);
            this.pageNum = arg0.pageNum || this.pageNum;
            this.service = arg0.service || this.service || service.getCountryRouteList;
        },
        html: function(data) {
            /*data = {
                data: [
                    {
                        url: 'http://plan.qyer.com/trip/V2AJY1FkBzBTY1I7/map',
                        img: 'http://pic.qyer.com/album/163/6e/1857093/index/500',
                        title: '标题',
                        city: ['澳门2', '香港2']
                    }
                ]
            };*/

            var tpl = this.template();
            var html = template.render(tpl, data);
            //console.log(tpl);
            //console.log(html);
            return html;
        },
        template: function() {
            return $('#country-route-tpl').html();
        },
        _load: function(page, success, err) {
            this.service(page, success, err);
        },
        load: function(page, success, err) {
            this._load(page, $.proxy(function(data) {
                success(data);
                this.checkData(data) && this.renderData(data);
            }, this), err);
        },
        renderData: function(data) {
            this.$().append(this.html(data));
        },
        checkData: function(data) {
            var hasData = data && data.data && data.data.length;

            //如果没有数据，或者返回的数据不足一页的时候触发LAST_PAGE事件
            if(!hasData || (hasData && data.data.length < this.pageNum)) {
                this.trigger(this.getStatic().EVENTS.LAST_PAGE);
            }
            
            return hasData;
        }
    }, {
        EVENTS: {
            LAST_PAGE: 'last_page'
        }
    });
});