"use strict";
define(["./widget", 'common/util/template', 'common/ui/swipe/swipe'], function(Widget, template) {
	return Widget.createClass({
        $el: '<div class="swipe img clearfix"><div class="swipe-wrap"></div></div>',
        items: null,
        swipe: null,
        init: function(params) {
            this.callSuper.apply(this, arguments);
            params = params || {};
            this.setItems(params.items || this.items);
        },
        render: function(append, items) {
            this.$('.swipe-wrap')[append ? 'append' : 'html'](this.html({data: items || this.items}));
        },
        html: function(data) {
            var tpl = this.template();
            var html = template.render(tpl, data);
            return html;
        },
        template: function() {
            return [
                '<%for(var i = 0, $item; $item = data && data[i]; i++) {%>',
                '<div><img data-original="<%=$item.src%>" src="http://static.qyer.com/images/m/space.png"><%if($item.author){%><span class="author">穷游er: <%=$item.author%></span><%}%></div>',
                '<%}%>'
            ].join('');
        },
        setItems: function(items) {
            this.items = items;
        },
        addItems: function(items) {
            this.items = (this.items||[]).concat(items);
            this.render(true, items);
            this.swipe.setup();
            this._initLazyload();
        },
        size: function() {
            return this.items && this.items.length || 0;
        },
        show: function(pos, items) {
            items && this.setItems(items);
            this.render();
            this._initSwipe({
                startSlide: pos
            });
            this._initLazyload();
            this.showImg(pos || 0);
        },
        _initSwipe: function(params) {
            this.swipe = this.$().Swipe($.extend({
                //auto: 3000,
                startSlide: 0,
                continuous: false,
                callback: $.proxy(function(pos, node) {
                    this.showImg(pos, node);
                }, this)
            }, params)).data('Swipe');
        },
        _initLazyload: function() {
            this.$('img:not(.lazyload)').lazyload({
                event: 'lazyload'
            }).addClass('lazyload');
        },
        getPos: function() {
            return this.swipe && this.swipe.getPos();
        },
        showImg: function(pos, node) {
            pos = pos || 0;
            node = node || this.$('.swipe-wrap>div').eq(pos);
            this.loadImg(node);
            this.trigger(this.getStatic().EVENTS.CHANGE, pos);
        },
        loadImg: function(node) {
            //预加载前2张和后2张图片
            var $node = $(node).add(this.getPrev(node, 2)).add(this.getNext(node, 2));
            $('img', $node).trigger('lazyload');
        },
        getNext: function(node, len) {
            var $next = $(node).next();
            if($next.length && len > 1) {
                return $next.add(this.getNext($next, len-1));
            }
            return $next;
        },
        getPrev: function(node, len) {
            var $prev = $(node).prev();
            if($prev.length && len > 1) {
                return $prev.add(this.getPrev($prev, len-1));
            }
            return $prev;
        }
    }, {
        EVENTS: {
            CHANGE: "change"
        }
    });
});