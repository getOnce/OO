define(['./widget', 'common/ui/loadmore/loadmore'], function(Widget) {
    "use strict";

    return Widget.createClass({
        autoLoadMore: true,
        init: function(arg0) {
            this.callSuper.apply(this, arguments);
            this.autoLoadMore = typeof arg0.autoLoadMore === 'undefined' ? this.autoLoadMore : arg0.autoLoadMore;
            this.start();
        },
        $box: function() {
            return this.$().parent();
        },
        setState: function(state) {
            this.$box().qyerLoadMore('setState', state);
        },
        next: function() {
            this.$box().qyerLoadMore('trigger');
        },
        start: function() {
            var i18n = this.i18n();
            this.$box().qyerLoadMore({
                el: this.$(),
                normalText: i18n.NORMAL_TEXT,
                loadingText: i18n.LOADING_TEXT,
                errorText: i18n.ERROR_TEXT,
                loadAllText: i18n.LOAD_ALL_TEXT,
                autoLoadMore: this.autoLoadMore,
                onLoadMore: $.proxy(function(page) {
                    this.trigger(this.getStatic().EVENTS.LOADMORE, page);
                }, this)
            });
        },
        stop: function() {
            $(window).off("scroll.loadmore");
            var loadmore = this.$box()[0].__loadMore__;
            loadmore.$loadBtn
            .off(qyerUtil.EVENT.CLICK)
            .find('span').html(loadmore.option.loadAllText || '');
        }
    }, {
        EVENTS: {
            LOADMORE: 'loadmore'
        }
    }).i18n({
        NORMAL_TEXT: '加载更多',
        LOADING_TEXT: '正在加载...',
        ERROR_TEXT: '网络不佳呢 <b>重新加载</b>',
        LOAD_ALL_TEXT: ''//加载完成
    });
});