define(['common/widget/widget-list-page', 'common/service/poi-service'], function(Widget, service) {
    "use strict";
    return Widget.createClass({
        service: service.getFavoritePoiList,
        template: function() {
            return $('#favorite-poi-list-tpl').html();
        }
    });
});