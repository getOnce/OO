"use strict";
define(["../lang/oo", "../lang/oo-event", '../lang/i18n'], function(oo, ooEvent, i18n) {
    return oo.createClass({
        $el: null,
        _event_alias: '__widget',
        /**
         * @params.events 事件代理
         * [
         *      [事件类型, 事件处理函数, selector],
         *      ['click', 'show', 'div.classname'],
         *      ['click', function(evt, widget){...}, 'div.classname'],
         *      ['click', function(evt, widget){...}, function() { return 'div.classname'; }],
         * ]
         */
        init: function(params) {
            params = params || {};
            this.callSuper.apply(this, arguments);
            this.$el = $(params.$el || this.$el);
            this.delegateEvents(this.events);
            this.delegateEvents(params.events);
        },
        $: function(selector) {
            return selector ? $(selector, this.$el) : this.$el;
        },
        delegateEvents: function(events) {
            events && $.each(events, $.proxy(function(index, eventItem) {
                this.delegateEvent.apply(this, eventItem);
            }, this));
            return this;
        },
        delegateEvent: function(eventType, callback, selector) {
            if(eventType && callback) {
                callback = typeof callback === 'string' && $.isFunction(this[callback]) ? $.proxy(this[callback], this) : $.proxy(callback, this);
                this.$el.on(eventType + '.' + this._event_alias, $.isFunction(selector) ? selector.call(this) : selector, callback);
            }
            return this;
        },
        undelegateEvents: function() {
            this.$el.off('.' + this._event_alias);
        },
        destroy: function() {
            this.undelegateEvents();
            for(var k in this) {
                if(this.hasOwnProperty(k)) {
                    //console.log(k, this[k]);
                    if(this[k] && $.isFunction(this[k].destroy)) {
                        try {
                            this[k].destroy();
                        } catch(e) {}
                    }
                    delete this[k];
                }
            }
        }
    }).implement(ooEvent).plugin(i18n);
});