define(['common/widget/widget', 'common/util/template', 'common/service/country-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
        pageNum: 10,
        maxPage: null,
        service: null,
        init: function(arg0) {
            this.callSuper.apply(this, arguments);
            this.pageNum = arg0.pageNum || this.pageNum;
            this.maxPage = arg0.maxPage || this.maxPage;
            this.service = arg0.service || this.service || service.getCountryDiscountList;
        },
        html: function(data) {
            var tpl = this.template();
            var html = template.render(tpl, data);
            //console.log(tpl);
            //console.log(html);
            return html;
        },
        template: function() {
            return $('#country-discount-tpl').html();
        },
        _load: function(page, success, err) {
            this.service(page, success, err);
        },
        load: function(page, success, err) {
            this._load(page, $.proxy(function(data) {
                //console.log(data);
                success(data);
                this.checkData(data, page) && this.renderData(data);
            }, this), err);
        },
        renderData: function(data) {
            this.$().append(this.html(data));
        },
        checkData: function(data, page) {
            var hasData = data && data.data && data.data.length;

            //如果没有数据，或者返回的数据不足一页的时候触发LAST_PAGE事件
            if(!hasData || (hasData && data.data.length < this.pageNum)
                //当前页大于最大页数
                || (this.maxPage && page >= this.maxPage)) {
                this.trigger(this.getStatic().EVENTS.LAST_PAGE);
            }
            
            return hasData;
        }
    }, {
        EVENTS: {
            LAST_PAGE: 'last_page'
        }
    });
});