define(['common/widget/widget-country-discount-list', 'common/util/template', 'common/service/discount-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
        service: service.getDiscountList,
        template: function() {
            return $('#discount-tpl').html();
        },
        checkData: function(data, page) {
            var hasData = data && data.data && data.data.list && data.data.list.length;

            //如果没有数据，或者返回的数据不足一页的时候触发LAST_PAGE事件
            if(!hasData || (hasData && data.data.list.length < this.pageNum)
                //当前页大于最大页数
                || (this.maxPage && page >= this.maxPage)) {
                this.trigger(this.getStatic().EVENTS.LAST_PAGE);
            }
            
            return hasData;
        }
    });
});