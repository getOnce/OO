define(['common/widget/widget-list', 'common/util/template', 'common/service/poi-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
        service: service.getTagByCategory,
        template: function() {
            return $('#tag-list-tpl').html();
        }
    });
});