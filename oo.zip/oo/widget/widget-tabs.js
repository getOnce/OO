define(["./widget", "common/ui/tabs/tabs"], function(Widget) {
    "use strict";
	var Tabs = Widget.createClass({
        init: function() {
        	var _this = this;
        	this.callSuper.apply(this, arguments);
            $(this.$el).qyerTabs({
                onSelect: function(tabNode) {
            		_this.trigger(Tabs.EVENTS.SELECT, tabNode);
                }
            });
        },
        reset: function() {
            this.$(".qui-tabNav li").removeClass("current");
        },
        getCurrentNode: function() {
            return this.$(".qui-tabNav li.current");
        },
        getText: function() {
            return $("span", this.getCurrentNode()).text(); 
        },
        setText: function(text) {
            $("span", this.getCurrentNode()).text(text);
        },
        setHighlight: function(flag) {
            this.getCurrentNode()[flag ? "addClass" : "removeClass"]("highlight");
        },
        setData: function(data) {
            this.getCurrentNode().data("data", data);
        },
        getData: function(name) {
            name = name || 'data';
            var data = this.getCurrentNode().data(name);
            return typeof data === 'undefined' || data === null ? '' : data;
        }
    }, {
        EVENTS: {
            SELECT: "select"
        }
    });

    return Tabs;
});