define(["./widget"], function(Widget) {
    "use strict";
    return Widget.createClass({
        getTrackNode: function() {
            return this.$('.' + this.getStatic().CLASS.TRACK);
        },
        getThumbNode: function() {
            return this.$('.' + this.getStatic().CLASS.THUMB);
        },
        resetHeight: function() {
            var class_ready = this.getStatic().CLASS.READY;
            var $node = this.$();
            $node.height('').removeClass(class_ready);
            $node.height($node.height()).addClass(class_ready);
            return this;
        }
    }, {
        CLASS: {
            //外层容器classname
            BOX: 'landscape-scrollbox',
            //轨道classname
            TRACK: 'landscape-scrollbox-track',
            //滑块classname
            THUMB: 'landscape-scrollbox-thumb',

            READY: 'ready'
        }
    });
});