define(['common/widget/widget-list', 'common/util/template', 'common/service/poi-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
    	pageNum: 10,
    	init: function(arg0) {
            this.callSuper.apply(this, arguments);
            this.pageNum = arg0.pageNum || this.pageNum;
        },
        checkData: function(data) {
            var hasData = data && data.data && data.data.length;

            //如果没有数据，或者返回的数据不足一页的时候触发LAST_PAGE事件
            if(!hasData || (hasData && data.data.length < this.pageNum)) {
                this.trigger(this.getStatic().EVENTS.LAST_PAGE);
            }
            
            return hasData;
        }
    }, {
        EVENTS: {
            LAST_PAGE: 'last_page'
        }
    });
});