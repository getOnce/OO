"use strict";
define(["./widget", "common/ui/popup_base/popup_base"], function(Widget, popup) {
	var DropdownWidget = Widget.createClass({
        _currentType: null,
        offsetTop: null,
        init: function(params) {
            params = params || {};
            this.callSuper.apply(this, arguments);
            this.offsetTop = params.offsetTop || this.offsetTop;
            this.bindEvents();
        },
        bindEvents: function() {
            var _this = this;
            $('.qui-popup-base')
            .on(qyerUtil.EVENT.CLICK, '.qui-popup-base_content', function(e) {
                if($(e.target).hasClass('qui-popup-base_content') || $(e.target).hasClass('popup-box')) {
                    //防止穿透问题
                    setTimeout(function(){
                        _this.hide();    
                    },100)
                    
                }
            })
            .on('touchmove', function(evt) {
                _this.cancelScroll(evt) && evt.preventDefault();
            });
        },
        show: function(type, html, immediateEvent) {
            var _this = this;
            this._currentType = type;
            this.clearHideTimer();
            $("html").addClass("show-dropdown-view");
            popup.show({
                type: 1,
                contentHTML: '<div class="popup-box transition">' + html + '</div>',
                immediateEvent: function(node) {
                    var offsetTop = _this.getOffsetTop();
                    offsetTop && $(node).css("padding-top", offsetTop);
                    $('.popup-box', node).addClass("popup-box-show");

                    $.isFunction(immediateEvent) && immediateEvent.apply(this, arguments);
                },
                onShow: function() {},
                onHide: function() {
                    _this._currentType = null;
                    $("html").removeClass("show-dropdown-view");
                    //tabs.reset();
                }
            });
        },
        _hide_timer: null,
        clearHideTimer: function() {
            clearTimeout(this._hide_timer);
        },
        hide: function() {
            $('.popup-box').removeClass("popup-box-show");
            $('.qui-popup-cover').removeClass('qui-popup-cover_show');
            //tabs.reset();
            this.clearHideTimer();
            this._hide_timer = setTimeout(function() {
                popup.hide();
            }, 250);
        },
        isCurrentType: function(type) {
            return this._currentType === type;
        },
        toggle: function(type, html, immediateEvent) {
            if(this.isCurrentType(type)) {
                this.hide();
            } else {
                this.show(type, html, immediateEvent);
            }
        },
        getOffsetTop: function() {
            return $.isFunction(this.offsetTop) && this.offsetTop() || this.offsetTop;
        },
        cancelScroll: function(evt) {
            return true;
        },
        reset: function() {
            $('.show-dropdown-view .qui-popup-base_content').css("padding-top", '');
            $("html").removeClass("show-dropdown-view");
            this._currentType = null;
        }
    }, {
        EVENTS: {
            SELECT: "select"
        }
    });

    return DropdownWidget;
});