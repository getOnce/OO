define(['common/widget/widget-country-discount-list', 'common/util/template', 'common/service/event-service'], function(Widget, template, service) {
    "use strict";
    return Widget.createClass({
        service: service.getPoiList,
        template: function() {
            return $('#event-poi-tpl').html();
        }
    });
});