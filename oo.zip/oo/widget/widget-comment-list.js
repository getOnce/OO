define(['common/widget/widget-list-page', 'common/service/comment-service', 'common/ui/toast/toast', 'common/widget/widget-img-swipe-popup'], function(Widget, service, Toast, ImgSwipePopup) {
    "use strict";
    return Widget.createClass({
        service: service.getCommentList,
        events: [
            [qyerUtil.EVENT.CLICK, '_evt_impress', '.place-comment-normal .praiseBtn .praise'],
            [qyerUtil.EVENT.CLICK, '_evt_showBigImg', '.place-comment-normal .place-comment-picture ul.list > li']
        ],
        checkData: function(data) {
            var hasData = data && data.data && data.data.res && data.data.res.length;

            //如果没有数据，或者返回的数据不足一页的时候触发LAST_PAGE事件
            if(!hasData || (hasData && data.data.res.length < this.pageNum)) {
                this.trigger(this.getStatic().EVENTS.LAST_PAGE);
            }
            
            return hasData;
        },
        template: function() {
            return $('#comment-list-tpl').html();
        },
        getNodeByPid: function(pid) {
        	return this.$('.place-comment-normal[data-id="' + pid + '"]');
        },
        _evt_impress: function(evt) {
        	var pid = $(evt.currentTarget).closest('.place-comment-normal').data('id');
            this.impress(pid);
        },
        impress: function(pid) {
        	if(!qyerUtil.isLogin()) {
		        qyerUtil.doLogin(document.location.href);
		        return;
		    }
		    var cb = $.proxy(function(data) {
        		switch((data||{}).error_code) {
        			case 0:
        				this.changePraise(pid);
        				break;
        			case 4:
        				this.showMsgByStr('warning', data && data.data && data.data.msg || this.i18n('ERROR_DUPLICATE'));
        				break;
        			default:
        				this.showMsg('error', 'ERROR');
        		}
        	}, this);
        	service.impress(pid, cb, cb);
        },
        changePraise: function(pid) {
        	var $node = this.getNodeByPid(pid).addClass('praiseed');
        	var $num = $('.praise .praise-num', $node);
        	var num = parseInt($num.html()) || 0;
        	$num.html(num+1);
        },
        showMsg: function(type, msg, isAutoHide, data) {
            return this.showMsgByStr(type, this.i18n(msg), isAutoHide, data);
        },
        showMsgByStr: function(type, msg, isAutoHide, data) {
            return new Toast({
                type: type,
                tips: data ? template.render(this.i18n(msg), data) : msg,
                isAutoHide: typeof isAutoHide === 'boolean' ? isAutoHide : true
            }).show();
        },
        _evt_showBigImg: function(evt) {
        	var $node = $(evt.currentTarget);
        	var pos = $node.index();
        	var items = $('>li img', $node.parent()).map(function(i, node) {
        		return {src: $(node).data('big') || node.src};
        	});
        	this.showBigImg(pos, items);
        },
        showBigImg: function(pos, items) {
        	this.imgSwipePopup && this.imgSwipePopup.destroy();
            this.imgSwipePopup = new ImgSwipePopup();
            this.imgSwipePopup.show(pos, items);
        }
    }).i18n({
        ERROR: '点赞失败',
        ERROR_DUPLICATE: '您已经点过有用了'
    });
});