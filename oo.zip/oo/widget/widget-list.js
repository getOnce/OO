define(['common/widget/widget', 'common/util/template'], function(Widget, template) {
    "use strict";
    return Widget.createClass({
        service: null,
        append: true,
        status: 0,
        init: function(arg0) {
            this.callSuper.apply(this, arguments);
            this.service = arg0.service || this.service;
            this.append = arg0.append || this.append;
        },
        html: function(data) {
            var tpl = this.template();
            var html = template.render(tpl, data);
            return html;
        },
        template: function() {
            return $('#list-tpl').html();
        },
        _load: function() {
            this.service.apply(this.service, arguments);
        },
        load: function(/*request, success, err*/) {
            var args = Array.prototype.slice.apply(arguments);

            var success = args[args.length - 2];
            args[args.length - 2] = $.proxy(function(data) {
                this.status = this.getStatic('STATUS').NORMAL;
                $.isFunction(success) && success.call(this, data);
                this.checkData.apply(this, [data].concat(args)) && this.renderData(data);
            }, this);

            var error = args[args.length - 1];
            args[args.length - 1] = $.proxy(function() {
                this.status = this.getStatic('STATUS').NORMAL;
                $.isFunction(error) && error.apply(this, arguments);
            }, this);

            this.status = this.getStatic('STATUS').LOADING;
            this._load.apply(this, args);
        },
        renderData: function(data) {
            this.$()[this.append ? 'append' : 'html'](this.html(data));
        },
        checkData: function(data, request) {
            return true;
        }
    }, {
        STATUS: {
            NORMAL: 0,
            LOADING: 1
        }
    });
});