requirejs.config({
	baseUrl: 'http://common1.qyerstatic.com/place-m/',
	map: {
		'*': {
			'css': 'common/basic/js/require-css'
		}
	}
});
