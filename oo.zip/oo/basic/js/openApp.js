$(document).ready(function(){
    "use strict";
    
    var launchapp = {
        
        checkCookie: function(){
            var cookies = document.cookie.split(";"), isShow = true;
            cookies.forEach(function(value, index, arr){
                if( $.trim( value.split('=')[0] ) == 'isShowAppBtn' ){
                    if(value.split('=')[1] == 'false'){
                        isShow = false;
                    }
                    
                }
            }, this);
            return isShow;
        },
        bindEvent: function(){
            var me = this;
            me
                .$el
                .on('click', '.close', function(e){
                    
                    me
                        .setCookie()
                        .$el
                        .hide();
                    me.freeze = true;
                    return false;
                })
                .on('click', function(){
                    if(me.freeze){
                        return false
                    }
                    me.freeze = true;
                    setTimeout(function(){
                        me.freeze = false;
                    }, 3000);

                    require(['common/util/appDownload'], function(appDownload){
                        var $a = me.$el.find('a');
                        appDownload({
                            universalLink: $a.attr('data-dpl'),
                            appDownloadPage: $a.attr('data-download'),
                            scheme: $a.attr('data-url'),
                            isUseUniversal: ($a.attr('data-isUseUniversal') == 'no'? false: true)
                        })
                    })
                });
            return this;    
        },
        setCookie: function(){
            var date=new Date();
            date.setTime(date.getTime()+24*3600*1000);
            document.cookie = "isShowAppBtn=false;expires="+ date.toGMTString() +";path=/";
            return this;
        },
        
        tpl: function(setting){
            return [
                '<section class="mGuideToAppBox">',
                    '<em class="close"></em>',
                    '<a href="javascript:void(0)" data-url="'+ setting.url +'" data-download="'+ setting.download +'" data-bn-ipg="'+ setting.databnipg +'" data-dpl='+ setting.dpl +' data-isUseUniversal='+ setting.isUseUniversal +'>',
                        '<img src="http://common1.qyerstatic.com/place-m/images/icon-logoGreen.png" class="logo">',
                        '<h4>下载穷游APP</h4>',
                        '<p>随时随地看攻略，查地图</p>',
                        '<span>马上下载</span>',
                    '</a>',
                '</section>'
            ].join('');
        },
        /**
        *检查是否在app打开
        *@return true 是在app打开
        *@return false 不是在app打开
        */
        check: function(){
            var ua = navigator.userAgent.indexOf("QYER");
            return ua === -1? false: true;
        },
        init: function(){
            
            if(this.check() || !this.checkCookie()){
                if($('.mGuideToAppBox').length > 0){
                    $('.mGuideToAppBox').hide();
                }
                
                return;
            }
            var appfrom = ~navigator.userAgent.toLowerCase().indexOf('android') ? 1 : 0;
            var defaultOpt = {
                url: '',
                // download: 'http://m.qyer.com/app/guide/?auto=1&campaign=app&category=H5xiazai',
                download: appfrom ? 'http://media.qyer.com/app/qyer-release-android' : 'https://itunes.apple.com/app/apple-store/id563467866?pt=832336&mt=8',
                query: '',
                databnipg: '',
                dpl: '',
                isUseUniversal: 'yes'
            }
            $.extend(defaultOpt, __lauchapp__);
            if($('.mGuideToAppBox').length == 0){
                $('body').prepend(this.tpl(defaultOpt));
            }
            this.$el = $('.mGuideToAppBox');
            this.bindEvent();
        }
        
    }
    launchapp.init();
    
})









